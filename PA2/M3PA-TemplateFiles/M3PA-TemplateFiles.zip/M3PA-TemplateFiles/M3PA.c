#include <stdio.h>
#include <stdlib.h>

/* add proper header documentation here */

int main() {

    printf("Welcome to M3PA\n");
    exit(EXIT_SUCCESS);
}
