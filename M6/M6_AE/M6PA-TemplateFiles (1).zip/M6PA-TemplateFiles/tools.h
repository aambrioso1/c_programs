// TODO - nothing, do not modify this file

#ifndef _TOOLS_H_
#define _TOOLS_H

// Prototypes of functions

char* taurahize_word(const char * const word);
char* taurahize_phrase(const char* const phrase);

#endif
