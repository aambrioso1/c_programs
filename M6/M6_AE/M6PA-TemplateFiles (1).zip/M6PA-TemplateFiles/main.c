// TODO - nothing, do not modify this file

#include <stdio.h>
#include <stdlib.h>

extern void runAllTests();

int main()
{
    printf("Welcome to the Tiny Taurahe Translator!!!\n\n\n");
    runAllTests();
    return EXIT_SUCCESS;
}
