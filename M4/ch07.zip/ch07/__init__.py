__all__ = ['circular_queue', 'favorites_list', 'favorites_list_mtf', 'insertion_sort_positional',
           'linked_deque', 'linked_queue', 'linked_stack', 'positional_list']
